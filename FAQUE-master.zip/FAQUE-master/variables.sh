#  Colors and function text && Global variables

final="\033[0m"
verde="\033[1;32m"
rojo="\033[0;31m"
amarillo="\033[1;33m"
azul="\033[0;34m"
blanco="\033[1;37m" 
naranja="\033[0;33m" 
negrita="\033[2m" 
cursiva="\033[3m"
parpadeo="\033[5m" 