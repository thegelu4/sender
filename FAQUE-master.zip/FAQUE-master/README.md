<h1 align="center"> <i> FAQUE V.1.0 </i> </h1>
<p align="center">
  <img width="350px" height="350px" src="https://i.postimg.cc/6pPQ4MfP/Black-and-White-Natural-Makeup-Logo.png" alt="Logo de FAQUE">
</p>
<hr>

[![version]][rp]
![Tested][tested]
![autor]

<h2 align="center"> FAQUE: is a hacking tool </h3>

<p align="center">
  <img src="https://user-images.githubusercontent.com/66902449/92422044-c42d7f00-f138-11ea-9c4c-c4e4bc7ce49c.png" alt="PREVIEW">
</p>

 * <b>Spoof Mail</b>: Now you can do spoof mail.
 * <b>Phishing</b>: With more 5+ TEMPLATES.
 
<hr>

# Requirements:

For users <b>Linux</b> and <b>Termux</b> users the requiriment are the same:

* [x] Kep OS update.
* [x] GIT.
* [x] Ngrok

<hr>

# Install:

[FAQUE LINUX][faque] o [FAQUE TERMUX][faque]
<br>


* _In directory where we want to clone the git:_

```sh
  git clone https://github.com/ByDog3r/FAQUE
```

* _Enter directory that makes:_
```sh
  cd FAQUE
```
* _we give execution permissions:_
```sh
   chmod +x faque.sh
```

* _Finally execute the script:_

<b>_Linux:_</b>
```sh
   ./gvngs.sh
```

<b>_Termux:_</b>
```sh
    bash Tgvngs.sh
```
<hr>

<h1 align="center"> ENJOY! </h1>


<p align="center">
  <img src="https://user-images.githubusercontent.com/66902449/90967466-eb2f5400-e49c-11ea-8665-e7ad18f0455a.jpg" alt="PREVIEW">
</p>

---

<!-- MarkDown Links & Images -->
[faque]: https://github.com/ByDog3r/FAQUE/blob/master/faque.sh
[autor]: https://img.shields.io/badge/Author%3A-%40ByDog3r-blueviolet "Autor."
[twitter]: https://twitter.com/ByDog3r "twitter"
[rp]: https://github.com/ByDog3r/GvngSearch "Repositorio en github"
[version]: https://img.shields.io/badge/Versi%C3%B3n%3A-BETA%3A%20V.1.0.2-orange "Repositorio"
[tested]: https://img.shields.io/badge/Probado%3A-Termux%20%7C%20Kali%20Linux%20%7C%20Parrot-informational "Testeado en: "
[preview]: https://user-images.githubusercontent.com/66902449/90967286-1feddc00-e49a-11ea-9e4f-5ef6f89e8ac7.png
[foloumi]: https://img.shields.io/twitter/follow/ByDog3r?style=social "Sigueme!"
[folowmi]: https://img.shields.io/github/followers/ByDog3r?style=social "Sigueme!"
[baidog]: https://github.com/ByDog3r
